package com.Conveau.Crypteau;

import java.io.*;
import java.math.BigInteger;
import java.nio.file.*;

import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;

public class NotoriousRNG {

    private final String s = "I remember my first time being written to disk.";
    private final byte[] data = s.getBytes();
    private Path p;

    private String line;
    private long rand_bit;
    private long time;
    private long nanotime_div_factor;
    private BigInteger range_min = BigInteger.valueOf(0);
    private BigInteger range_max = BigInteger.valueOf(0);
    private int bit_length = 0;
    private BigInteger rand_num;
    private BigInteger range;
    private int range_num_bits;
    private BigInteger final_num;
    private byte[] rand_num_byte_array;
    private String rand_num_bin_string;
    private String range_bin_string;
    private String range_minus_MS_bit_string;
    private BigInteger range_minus_MS_bit_num;
    private BigInteger rand_num_minus_MS_bit;
    private int compare_value;
    private Object delay = new Object();
    private long[] nanotime_samples;
    private int nanotime_num_digits;
    private long dec_div_factor;
    private boolean check_done;


    public NotoriousRNG() {

        this.p = Paths.get("./file_" + System.nanoTime() + ".txt");

        checkNanoTime();
    }

    public NotoriousRNG(int num_bits) {

        this.p = Paths.get("./file_" + System.nanoTime() + ".txt");

        if (num_bits < 1) {
            System.err.println("Please input a bit length greater than zero. Thanks.");
            System.exit(1);
        }
        else {
            this.bit_length = num_bits;
        }

        checkNanoTime();
    }

    public NotoriousRNG(BigInteger range_min_value, BigInteger range_max_value) {

        this.p = Paths.get("./file_" + System.nanoTime() + ".txt");

        this.range_min = range_min_value;

        this.range_max = range_max_value;

        this.compare_value = this.range_min.compareTo(this.range_max);

        if (this.compare_value == 1 || this.compare_value == 0) {

            System.err.println("Please make sure the range max value is greater than the range min value. Thanks.");
            System.exit(1);
        }
        else {
            this.range = this.range_max.subtract(this.range_min);
        }

        checkNanoTime();
    }

    private void checkNanoTime() {

        this.nanotime_samples= new long[10];

        for (int i = 0; i < 10; i++) {

            this.nanotime_samples[i] = System.nanoTime();
        }

        this.nanotime_num_digits = Long.toString(this.nanotime_samples[0]).length();

        this.dec_div_factor = 1;

        this.check_done = false;

        for (int i = 0; i < this.nanotime_num_digits; i++) {

            this.dec_div_factor *= 10;

            for (int j = 0; j < 10; j++) {
                if (this.nanotime_samples[j] % this.dec_div_factor != 0) {
                    this.check_done = true;
                }
            }

            if (this.check_done) {
                break;
            }
        }

        this.nanotime_div_factor = this.dec_div_factor/10;
    }

    private byte getBlackjackBit() {

        try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(this.p, CREATE, APPEND)))
        {
            out.write(data, 0, data.length);

            synchronized(this.delay) {
                try {
                    this.delay.wait(0, (int)this.nanotime_div_factor);
                } catch (InterruptedException x) {

                }
            }
        } catch (IOException x) {
            System.err.println(x);
            System.exit(1);
        }

        try (InputStream in = Files.newInputStream(this.p);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in)))
        {
            try {
                this.line = reader.readLine();
            } catch (IOException x) {
                System.err.println(x);
                System.exit(1);
            }

            synchronized(this.delay) {
                try {
                    this.delay.wait(0, (int)this.nanotime_div_factor);
                } catch (InterruptedException x) {

                }
            }
        } catch (IOException x) {
            System.err.println(x);
            System.exit(1);
        }

        try {
            Files.delete(this.p);
        } catch (NoSuchFileException x) {
            System.err.format("%s: no such" + " file or directory%n", this.p);
            System.exit(1);
        } catch (DirectoryNotEmptyException x) {
            System.err.format("%s not empty%n", this.p);
            System.exit(1);
        } catch (IOException x) {
            System.err.println(x);
            System.exit(1);
        }

        this.time = System.nanoTime()/this.nanotime_div_factor;

        this.rand_bit = this.time % 2;

        return (byte)this.rand_bit;
    }

    public BigInteger getRandomNumber() {

        this.compare_value = this.range_min.compareTo(this.range_max);

        if (this.compare_value == 1 || this.compare_value == 0) {
            System.err.println("Please make sure that the range max value is greater than the range min value. Thanks.");
            System.exit(1);
        }
        else {
            this.range = this.range_max.subtract(this.range_min);
        }

        this.rand_num_bin_string = "";

        this.range_bin_string = this.range.toString(2);

        this.range_num_bits = this.range.bitLength();

        if (this.range_num_bits > 1) {

            this.range_minus_MS_bit_string = this.range_bin_string.substring(1); // MS = most significant

            this.range_minus_MS_bit_num = new BigInteger(this.range_minus_MS_bit_string, 2);

            for (int i = 0; i < this.range_num_bits - 1; i++) {

                this.rand_num_bin_string = Byte.toString(getBlackjackBit()).concat(this.rand_num_bin_string);
            }

            this.rand_num_minus_MS_bit = new BigInteger(this.rand_num_bin_string, 2);

            this.compare_value = this.rand_num_minus_MS_bit.compareTo(this.range_minus_MS_bit_num);

            if (this.compare_value == 0 || this.compare_value == -1) {

                this.rand_num_bin_string = Byte.toString(getBlackjackBit()).concat(this.rand_num_bin_string);
            }
        }
        else {
            this.rand_num_bin_string = Byte.toString(getBlackjackBit()).concat(this.rand_num_bin_string);
        }

        this.rand_num = new BigInteger(this.rand_num_bin_string, 2);

        this.final_num = this.range_min.add(this.rand_num);

        return this.final_num;
    }

    public byte[] getRandomBits() {

        if (this.bit_length < 1) {
            System.err.println("Please input a bit length greater than zero. Thanks.");
            System.exit(1);
        }

        this.rand_num_bin_string = "";

        for (int i = 0; i < this.bit_length; i++) {

            this.rand_num_bin_string = Byte.toString(getBlackjackBit()).concat(this.rand_num_bin_string);
        }

        this.rand_num = new BigInteger(this.rand_num_bin_string, 2);

        this.rand_num_byte_array = this.rand_num.toByteArray();

        return this.rand_num_byte_array;
    }

    public void setRangeMin(BigInteger min_value) {

        this.range_min = min_value;
    }

    public BigInteger getRangeMin() {

        return this.range_min;
    }

    public void setRangeMax(BigInteger max_value) {

        this.range_max = max_value;
    }

    public BigInteger getRangeMax() {

        return this.range_max;
    }

    public void setBitLength(int num_bits) {

        this.bit_length = num_bits;
    }

    public int getBitLength() {

        return this.bit_length;
    }
}
